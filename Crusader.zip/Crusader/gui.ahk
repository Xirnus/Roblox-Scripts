#Requires AutoHotkey v2.0

if !IsSet(MyGui) {
    MyGui := Gui("+AlwaysOnTop")  ; Keeps GUI above game window
    MyGui.Title := "Yippie Macro"
    MyGui.SetFont("s10", "Segoe UI")


    ; Win/Loss counters side-by-side
    MyGui.Add("Text", "vWinText x20 y+20 w120", "Wins: 0")
    MyGui.Add("Text", "vLoseText x160 yp w120", "Losses: 0")
    
    ; Units Placements section
    MyGui.Add("Text", "x20 y+30 w200", "Units Placements:")
    
    ; Unit text boxes in a grid layout
    MyGui.Add("Text", "x20 y+10 w50", "Unit 1:")
    MyGui.Add("Edit", "vUnit1 x80 yp w100 Limit1 Number")
    MyGui.Add("Text", "x200 yp w50", "Unit 2:")
    MyGui.Add("Edit", "vUnit2 x260 yp w100 Limit1 Number")
    
    MyGui.Add("Text", "x20 y+30 w50", "Unit 3:")
    MyGui.Add("Edit", "vUnit3 x80 yp w100 Limit1 Number")
    MyGui.Add("Text", "x200 yp w50", "Unit 4:")
    MyGui.Add("Edit", "vUnit4 x260 yp w100 Limit1 Number")
    
    MyGui.Add("Text", "x20 y+30 w50", "Unit 5:")
    MyGui.Add("Edit", "vUnit5 x80 yp w100 Limit1 Number")
    MyGui.Add("Text", "x200 yp w50", "Unit 6:")
    MyGui.Add("Edit", "vUnit6 x260 yp w100 Limit1 Number")
}

MoveGui(){
    global MyGui, RobloxWindow

    if WinExist(RobloxWindow) {
        WinGetPos(&x, &y, &w, &h, RobloxWindow)
        ; Show GUI to the right of Roblox window
        MyGui.Show("x" (x + w + 10) " y" y " w300 h150")
    } else {
        MyGui.Show("w300 h150")
    }
}

ShowGUI() {
    MyGui.Show("w400 h400")
}
